---
name: Bug report
about: Report an installation issue without sharing private data
title: "[Bug] "
labels: bug
---

**Mac model / Intel CPU:**

**macOS version:**

**Horos version/build:**

**Step and exact error message:**

**Expected vs actual behavior:**

Do not upload DICOM patient studies or confidential data.
